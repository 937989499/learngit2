// $(function($){
// 	$.cceshi = function(){
// 		this.publicdatadig = function(a,b,c){
// 			$(a).datagrid({
// 				url : './'.b.'/'.b.'_data.php',
// 				fit : true,
// 				fitColumns : true,
// 				striped : true,
// 				rownumbers : true,
// 				border : false,
// 				pagination : true,
// 				pageSize : 20,
// 				pageList : [10, 20, 30, 40, 50],
// 				pageNumber : 1,
// 				sortName : 'Id',
// 				toolbar : ''.a.'.'_tool'',
// 				columns : '[['.c.']]',
// 			});
// 		}
// 	}
// });